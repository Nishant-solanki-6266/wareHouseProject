export const initialAuditLogs = [
  {
    id: "AUD-9912",
    timestamp: "2026-08-29 10:15 AM",
    user: "David Cartwright (Agent)",
    module: "Agent Portal",
    action: "Attempted Document Download (Blocked)",
    recordId: "BL-VI-2026-0092",
    description: "Agent attempted download of Master B/L BL-VI-2026-0092. Action restricted due to ACTIVE HOLD status.",
    ipAddress: "197.238.10.42 (Nassau, BS)"
  },
  {
    id: "AUD-9911",
    timestamp: "2026-08-29 09:30 AM",
    user: "Sarah Jenkins (Documentation)",
    module: "Shipping Manifest",
    action: "Generated Manifest",
    recordId: "MNF-2026-0442",
    description: "Generated Outward Shipping Manifest MNF-2026-0442 for MV Island Voyager (Voyage V.2026-19E).",
    ipAddress: "10.0.4.18 (HQ Miami)"
  },
  {
    id: "AUD-9910",
    timestamp: "2026-08-28 02:45 PM",
    user: "Sarah Jenkins (Documentation)",
    module: "Bill of Lading",
    action: "Placed B/L On Hold",
    recordId: "BL-VI-2026-0092",
    description: "Placed Master B/L BL-VI-2026-0092 On Hold. Reason: 'Payment Pending: Freight & Documentation Charges Unsettled'.",
    ipAddress: "10.0.4.18 (HQ Miami)"
  },
  {
    id: "AUD-9909",
    timestamp: "2026-08-28 09:15 AM",
    user: "Marcus Vance (Super Admin)",
    module: "Bill of Lading",
    action: "Cleared Hold & Released B/L",
    recordId: "BL-VI-2026-0089",
    description: "Authorized hold release for Master B/L BL-VI-2026-0089. Status changed from On Hold to RELEASED.",
    ipAddress: "10.0.4.10 (HQ Miami)"
  },
  {
    id: "AUD-9908",
    timestamp: "2026-08-28 08:15 AM",
    user: "Carlos Mendez (Warehouse)",
    module: "Consolidation",
    action: "Created Consolidated Shipment",
    recordId: "CNS-2026-0819",
    description: "Consolidated Warehouse Receipts [WR-2026-1043, WR-2026-1038, WR-2026-1039] into Container MSKU-948291-4.",
    ipAddress: "10.0.8.22 (CFS Bay 4)"
  },
  {
    id: "AUD-9907",
    timestamp: "2026-08-27 09:30 AM",
    user: "Carlos Mendez (Warehouse)",
    module: "Warehouse Receipt",
    action: "Created Warehouse Receipt",
    recordId: "WR-2026-1041",
    description: "Created WR-2026-1041 for Atlantic Trading Co. (14 Cartons, 1850 lbs, 10.41 CBM).",
    ipAddress: "10.0.8.22 (CFS Bay 4)"
  }
];
