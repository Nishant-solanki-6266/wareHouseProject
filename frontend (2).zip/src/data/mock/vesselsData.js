export const initialVessels = [
  {
    id: "VSL-001",
    name: "MV Caribbean Carrier",
    imoNumber: "9482019",
    flag: "Bahamas",
    type: "Container Carrier / Ro-Ro",
    carrier: "Tropical Shipping Line",
    capacityTeu: 1200,
    deadweightTonnage: 14500,
    builtYear: 2018,
    status: "At Sea",
    currentVoyage: "V.2026-18W",
    activeRoute: "Miami (USMIA) → Kingston (JMKIN)",
    etaNextPort: "2026-09-02 06:00 AM"
  },
  {
    id: "VSL-002",
    name: "MV Island Voyager",
    imoNumber: "9371820",
    flag: "Panama",
    type: "Geared Container Vessel",
    carrier: "Tropical Shipping Line",
    capacityTeu: 950,
    deadweightTonnage: 11200,
    builtYear: 2016,
    status: "Docked (Port Everglades)",
    currentVoyage: "V.2026-19E",
    activeRoute: "Port Everglades (USPEF) → Nassau (BSNAS)",
    etaNextPort: "2026-09-01 07:00 AM"
  },
  {
    id: "VSL-003",
    name: "MV Atlantic Pioneer",
    imoNumber: "9618293",
    flag: "Liberia",
    type: "Feeder Container Ship",
    carrier: "Crowley Liner Services",
    capacityTeu: 1500,
    deadweightTonnage: 18000,
    builtYear: 2020,
    status: "At Sea",
    currentVoyage: "V.2026-09S",
    activeRoute: "Miami (USMIA) → Bridgetown (BBBGI)",
    etaNextPort: "2026-09-01 08:00 AM"
  },
  {
    id: "VSL-004",
    name: "MV Tropical Navigator",
    imoNumber: "9283710",
    flag: "Cyprus",
    type: "Multi-Purpose Cargo Ship",
    carrier: "King Ocean Services",
    capacityTeu: 1100,
    deadweightTonnage: 13800,
    builtYear: 2015,
    status: "Scheduled",
    currentVoyage: "V.2026-21E",
    activeRoute: "Miami (USMIA) → Port of Spain (TTPOS)",
    etaNextPort: "2026-09-05 06:00 PM"
  }
];

export const initialVoyages = [
  {
    id: "VOY-2026-18W",
    voyageNumber: "V.2026-18W",
    vesselId: "VSL-001",
    vesselName: "MV Caribbean Carrier",
    carrier: "Tropical Shipping Line",
    originPort: "Port of Miami (USMIA)",
    destinationPort: "Port of Kingston (JMKIN)",
    departureDate: "2026-08-28",
    arrivalDate: "2026-09-02",
    status: "In Transit",
    assignedShipmentsCount: 3,
    totalTeuUtilized: 1.0
  },
  {
    id: "VOY-2026-19E",
    voyageNumber: "V.2026-19E",
    vesselId: "VSL-002",
    vesselName: "MV Island Voyager",
    carrier: "Tropical Shipping Line",
    originPort: "Port Everglades (USPEF)",
    destinationPort: "Port of Nassau (BSNAS)",
    departureDate: "2026-08-30",
    arrivalDate: "2026-09-01",
    status: "Loading",
    assignedShipmentsCount: 2,
    totalTeuUtilized: 2.0
  },
  {
    id: "VOY-2026-09S",
    voyageNumber: "V.2026-09S",
    vesselId: "VSL-003",
    vesselName: "MV Atlantic Pioneer",
    carrier: "Crowley Liner Services",
    originPort: "Port of Miami (USMIA)",
    destinationPort: "Port of Bridgetown (BBBGI)",
    departureDate: "2026-08-26",
    arrivalDate: "2026-09-01",
    status: "In Transit",
    assignedShipmentsCount: 1,
    totalTeuUtilized: 1.0
  }
];
