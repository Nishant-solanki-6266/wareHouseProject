// Initial seed for House Bills of Lading (HBL)
export const initialHouseBills = [
  {
    id: "HBL-2026-0001",
    hblNumber: "HBL-2026-0001",
    customerId: "CUS-2026-0001",
    customerName: "Atlantic Trading Co.",
    shipper: {
      name: "Global Retail Suppliers Inc.",
      address: "8200 NW 33rd Street, Miami, FL 33122, USA",
      contact: "Robert Sterling (+1 305-555-0199)"
    },
    consignee: {
      name: "Atlantic Trading Co.",
      address: "Bay Street Commercial Centre, Suite 300, Nassau, Bahamas",
      taxId: "TIN-BS-994821",
      contact: "Marcus Vance (+1 242-555-0144)"
    },
    notifyParty: {
      name: "Caribbean Express Freight Ltd. (Local Port Agent)",
      address: "Arawak Cay Cargo Terminal, Suite 2B, Nassau, Bahamas",
      contact: "Operations (+1 242-555-9000)"
    },
    agentId: "AGT-001",
    agentName: "Caribbean Express Freight Ltd.",
    originPort: "Port of Miami (USMIA), FL",
    destinationPort: "NAS - Nassau, Bahamas",
    destinationCode: "NAS",
    warehouseReceiptIds: ["3100"],
    cargoDescription: "Commercial Kitchen Appliances & Stainless Steel Cookware",
    packages: [
      {
        id: "PKG-WR1041-01",
        packageType: "Carton",
        description: "Commercial Kitchen Appliances (Ovens, Mixers)",
        lengthInches: 42,
        widthInches: 38,
        heightInches: 48,
        weightLbs: 1200,
        pieces: 8,
        cft: 207.67,
        cbm: 5.88
      },
      {
        id: "PKG-WR1041-02",
        packageType: "Carton",
        description: "Stainless Steel Cookware Sets & Accessories",
        lengthInches: 36,
        widthInches: 30,
        heightInches: 36,
        weightLbs: 650,
        pieces: 6,
        cft: 135.0,
        cbm: 3.82
      }
    ],
    totalPackages: 2,
    totalPieces: 14,
    totalWeightLbs: 1850,
    totalWeightKg: 839.1,
    totalCft: 342.67,
    totalCbm: 9.70,
    status: "Active",
    freightTerms: "Freight Prepaid",
    createdDate: "2026-08-27",
    issueDate: "2026-08-27",
    assignedConsolidationId: null,
    assignedMasterBLId: null,
    assignedShipmentId: null,
    notes: "Fragile items. Handle with forklift. Clean shrink-wrap."
  },
  {
    id: "HBL-2026-0002",
    hblNumber: "HBL-2026-0002",
    customerId: "CUS-2026-0002",
    customerName: "Nassau Wholesale Goods Ltd.",
    shipper: {
      name: "American Food Distributors",
      address: "10400 NW 21st St, Doral, FL 33172, USA",
      contact: "James Wilson (+1 305-555-8822)"
    },
    consignee: {
      name: "Nassau Wholesale Goods Ltd.",
      address: "East Street & Robinson Road, Nassau, Bahamas",
      taxId: "TIN-BS-883910",
      contact: "David Cartwright (+1 242-555-4812)"
    },
    notifyParty: {
      name: "Caribbean Express Freight Ltd.",
      address: "Arawak Cay Cargo Terminal, Suite 2B, Nassau, Bahamas",
      contact: "Duty Officer (+1 242-555-9000)"
    },
    agentId: "AGT-001",
    agentName: "Caribbean Express Freight Ltd.",
    originPort: "Port of Miami (USMIA), FL",
    destinationPort: "NAS - Nassau, Bahamas",
    destinationCode: "NAS",
    warehouseReceiptIds: ["3101"],
    cargoDescription: "Dry Packaged Groceries & Non-Perishable Canned Goods",
    packages: [
      {
        id: "PKG-WR1042-01",
        packageType: "Pallet",
        description: "Assorted Canned Soups, Vegetables & Beans",
        lengthInches: 48,
        widthInches: 40,
        heightInches: 60,
        weightLbs: 3400,
        pieces: 12,
        cft: 800.0,
        cbm: 22.65
      },
      {
        id: "PKG-WR1042-02",
        packageType: "Pallet",
        description: "Dry Pasta, Rice & Cooking Oils",
        lengthInches: 48,
        widthInches: 40,
        heightInches: 60,
        weightLbs: 3000,
        pieces: 10,
        cft: 666.67,
        cbm: 18.88
      }
    ],
    totalPackages: 2,
    totalPieces: 22,
    totalWeightLbs: 6400,
    totalWeightKg: 2903.0,
    totalCft: 1466.67,
    totalCbm: 41.53,
    status: "Active",
    freightTerms: "Freight Prepaid",
    createdDate: "2026-08-27",
    issueDate: "2026-08-27",
    assignedConsolidationId: null,
    assignedMasterBLId: null,
    assignedShipmentId: null,
    notes: "Standard heat-treated wooden pallets."
  },
  {
    id: "HBL-2026-0003",
    hblNumber: "HBL-2026-0003",
    customerId: "CUS-2026-0003",
    customerName: "Kingston Hardware & Building Supplies",
    shipper: {
      name: "US Heavy Building Materials",
      address: "Tampa Bay Industrial Port, Tampa, FL 33605",
      contact: "Mark Vance (+1 813-555-9120)"
    },
    consignee: {
      name: "Kingston Hardware & Supplies Ltd.",
      address: "24 Marcus Garvey Drive, Industrial Estate, Kingston 11, Jamaica",
      taxId: "TRN-JM-884719",
      contact: "Anthony Campbell (+1 876-555-2341)"
    },
    notifyParty: {
      name: "Kingston Port Logistics Ltd.",
      address: "Kingston Wharves Berth 7, Newport West, Kingston, Jamaica",
      contact: "Duty Officer (+1 876-555-9800)"
    },
    agentId: "AGT-002",
    agentName: "Kingston Port Logistics Ltd.",
    originPort: "Port of Miami (USMIA), FL",
    destinationPort: "KIN - Kingston, Jamaica",
    destinationCode: "KIN",
    warehouseReceiptIds: ["3102"],
    cargoDescription: "Power Hand Tools, Fasteners & Construction Hardware",
    packages: [
      {
        id: "PKG-WR1043-01",
        packageType: "Wooden Crate",
        description: "Industrial Fasteners, Bolts & Anchors",
        lengthInches: 36,
        widthInches: 36,
        heightInches: 40,
        weightLbs: 1800,
        pieces: 10,
        cft: 300.0,
        cbm: 8.50
      },
      {
        id: "PKG-WR1043-02",
        packageType: "Wooden Crate",
        description: "Heavy Duty Power Drills, Saws & Generators",
        lengthInches: 36,
        widthInches: 36,
        heightInches: 40,
        weightLbs: 1400,
        pieces: 8,
        cft: 240.0,
        cbm: 6.80
      }
    ],
    totalPackages: 2,
    totalPieces: 18,
    totalWeightLbs: 3200,
    totalWeightKg: 1451.5,
    totalCft: 540.0,
    totalCbm: 15.29,
    status: "Consolidated",
    freightTerms: "Freight Prepaid",
    createdDate: "2026-08-28",
    issueDate: "2026-08-28",
    assignedConsolidationId: "CNS-2026-0819",
    assignedMasterBLId: "BL-VI-2026-0089",
    assignedShipmentId: "SHP-2026-0291",
    notes: "Consolidated in Kingston LCL Ocean Box #18."
  },
  {
    id: "HBL-2026-0004",
    hblNumber: "HBL-2026-0004",
    customerId: "CUS-2026-0005",
    customerName: "Bahamas Marine & Auto Parts",
    shipper: {
      name: "Florida Marine Spares",
      address: "1200 Bryan Rd, Dania Beach, FL 33004",
      contact: "Frank Reynolds (+1 954-555-3310)"
    },
    consignee: {
      name: "Bahamas Marine Spares",
      address: "Shirley Street & Mackey St, Nassau, Bahamas",
      taxId: "TIN-BS-771829",
      contact: "Gary Knowles (+1 242-555-9922)"
    },
    notifyParty: {
      name: "Caribbean Express Freight Ltd.",
      address: "Arawak Cay Cargo Terminal, Suite 2B, Nassau, Bahamas",
      contact: "Operations (+1 242-555-9000)"
    },
    agentId: "AGT-001",
    agentName: "Caribbean Express Freight Ltd.",
    originPort: "Port Everglades (USPEF), FL",
    destinationPort: "NAS - Nassau, Bahamas",
    destinationCode: "NAS",
    warehouseReceiptIds: ["3104"],
    cargoDescription: "Outboard Engine Replacement Parts & Marine Lubricants",
    packages: [
      {
        id: "PKG-WR1045-01",
        packageType: "Skid",
        description: "Outboard Impellers, Gaskets & Spark Plugs",
        lengthInches: 44,
        widthInches: 44,
        heightInches: 32,
        weightLbs: 500,
        pieces: 3,
        cft: 107.56,
        cbm: 3.05
      },
      {
        id: "PKG-WR1045-02",
        packageType: "Skid",
        description: "2-Stroke Marine Engine Oil (Sealed Drums)",
        lengthInches: 44,
        widthInches: 44,
        heightInches: 32,
        weightLbs: 480,
        pieces: 3,
        cft: 107.56,
        cbm: 3.05
      }
    ],
    totalPackages: 2,
    totalPieces: 6,
    totalWeightLbs: 980,
    totalWeightKg: 444.5,
    totalCft: 215.11,
    totalCbm: 6.09,
    status: "Active",
    freightTerms: "Freight Prepaid",
    createdDate: "2026-08-28",
    issueDate: "2026-08-28",
    assignedConsolidationId: null,
    assignedMasterBLId: null,
    assignedShipmentId: null,
    notes: "Non-hazardous marine lubricant drums strapped to skids."
  }
];
