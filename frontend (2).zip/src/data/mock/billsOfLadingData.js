export const initialBillsOfLading = [
  {
    id: "BL-VI-2026-0092",
    blNumber: "BL-VI-2026-0092",
    type: "Master Ocean Bill of Lading",
    status: "On Hold", // Critical Hold Demo
    shipmentId: "SHP-2026-0290",
    shipmentNumber: "SHP-2026-0290",
    consolidationId: "CNS-2026-0817",
    houseBillIds: ["HBL-2026-0001", "HBL-2026-0002", "HBL-2026-0004"],
    createdDate: "2026-08-28",
    issueDate: "2026-08-28",
    shipper: {
      name: "Global Food & Marine Suppliers Inc.",
      address: "8300 NW 33rd Street, Suite 400, Miami, FL 33122, USA",
      taxId: "EIN-59-2938104",
      contact: "Robert Sterling (+1 305-555-0199)"
    },
    consignee: {
      name: "Nassau Wholesale Goods Ltd. / Atlantic Trading Co.",
      address: "East Street & Bay Street Commercial Complex, Nassau, Bahamas",
      taxId: "TIN-BS-994821",
      contact: "David Cartwright (+1 242-555-4812)"
    },
    notifyParty: {
      name: "Caribbean Express Freight Ltd. (Local Port Agent)",
      address: "Arawak Cay Cargo Terminal, Suite 2B, Nassau, Bahamas",
      contact: "Operations Dept (+1 242-555-9000)"
    },
    agentId: "AGT-001",
    agentName: "Caribbean Express Freight Ltd.",
    preCarriageBy: "VI Inland Drayage",
    placeOfReceipt: "VI CFS Miami Warehouse",
    oceanVessel: "MV Island Voyager",
    voyageNumber: "V.2026-19E",
    carrier: "Tropical Shipping Line",
    portOfLoading: "Port Everglades (USPEF), FL, USA",
    portOfDischarge: "Port of Nassau (BSNAS), Bahamas",
    placeOfDelivery: "Nassau Container Terminal (Arawak Cay)",
    containerNumber: "CMAU-109482-7",
    sealNumber: "SEAL-VI-77491",
    containerType: "40' Standard GP",
    marksAndNumbers: "NAS/KERS/2026/0092\nCONTAINER: CMAU-109482-7\nSEAL: SEAL-VI-77491",
    cargoDescription: "Consolidated Cargo: 22 Pallets Assorted Canned Groceries, 14 Cartons Commercial Kitchen Appliances & 6 Skids Marine Engine Parts.",
    packageCount: 6,
    totalPieces: 42,
    packageType: "Pallets / Cartons / Skids",
    grossWeightLbs: 9230,
    grossWeightKg: 4186.6,
    cbm: 57.32,
    cft: 2024.45,
    freightPayableAt: "Miami, FL",
    freightTerms: "Freight Prepaid",
    numberOfOriginals: "3 (THREE)",
    // Hold Details
    holdDetails: {
      isOnHold: true,
      reason: "Payment Pending: Freight & Documentation Charges Unsettled",
      placedBy: "Finance & Accounts Dept (Sarah Jenkins)",
      placedAt: "2026-08-28 02:45 PM",
      holdCategory: "Financial Clearance",
      holdNotes: "Awaiting incoming wire transfer confirmation ($3,840.00 USD). Release document only upon accounting sign-off.",
      contactEmail: "accounting@vicustoms.com",
      contactPhone: "+1 (305) 555-KERS Ext 4"
    },
    charges: [
      { description: "Ocean Freight (LCL Consolidated 40FT)", rate: "$55.00 / CBM", amount: 3152.60, prepaid: true },
      { description: "B/L Documentation & Processing Fee", rate: "Flat", amount: 150.00, prepaid: true },
      { description: "Terminal Handling Charges (THC)", rate: "Flat", amount: 350.00, prepaid: true },
      { description: "Security & ISPS Surcharge", rate: "Flat", amount: 75.00, prepaid: true }
    ],
    totalFreightUsd: 3727.60
  },
  {
    id: "BL-VI-2026-0089",
    blNumber: "BL-VI-2026-0089",
    type: "Master Ocean Bill of Lading",
    status: "Released",
    shipmentId: "SHP-2026-0291",
    shipmentNumber: "SHP-2026-0291",
    consolidationId: "CNS-2026-0819",
    houseBillIds: ["HBL-2026-0003"],
    createdDate: "2026-08-27",
    issueDate: "2026-08-28",
    shipper: {
      name: "US Heavy Building Materials & Hardware Corp",
      address: "10400 NW 21st St, Doral, FL 33172, USA",
      taxId: "EIN-65-8839201",
      contact: "Mark Vance (+1 305-555-8841)"
    },
    consignee: {
      name: "Kingston Hardware & Supplies Ltd.",
      address: "24 Marcus Garvey Drive, Industrial Estate, Kingston 11, Jamaica",
      taxId: "TRN-JM-884719",
      contact: "Anthony Campbell (+1 876-555-2341)"
    },
    notifyParty: {
      name: "Kingston Port Logistics Ltd.",
      address: "Kingston Wharves Berth 7, Newport West, Kingston, Jamaica",
      contact: "Duty Officer (+1 876-555-9800)"
    },
    agentId: "AGT-002",
    agentName: "Kingston Port Logistics Ltd.",
    preCarriageBy: "VI Inland Drayage",
    placeOfReceipt: "CFS Miami",
    oceanVessel: "MV Caribbean Carrier",
    voyageNumber: "V.2026-18W",
    carrier: "Tropical Shipping Line",
    portOfLoading: "Port of Miami (USMIA), FL",
    portOfDischarge: "Port of Kingston (JMKIN), Jamaica",
    placeOfDelivery: "Kingston Wharves CFS Berth 7",
    containerNumber: "MSKU-948291-4",
    sealNumber: "SEAL-VI-99482",
    containerType: "40' High Cube",
    marksAndNumbers: "KIN/KERS/2026/0089\nCONTAINER: MSKU-948291-4\nSEAL: SEAL-VI-99482",
    cargoDescription: "Power Hand Tools, Fasteners, Construction Hardware in 18 Wooden Crates.",
    packageCount: 2,
    totalPieces: 18,
    packageType: "Wooden Crates",
    grossWeightLbs: 3200,
    grossWeightKg: 1451.5,
    cbm: 15.29,
    cft: 540.0,
    freightPayableAt: "Miami, FL",
    freightTerms: "Freight Prepaid",
    numberOfOriginals: "3 (THREE)",
    holdDetails: {
      isOnHold: false,
      reason: null,
      releasedBy: "Marcus Vance (Senior Documentation Lead)",
      releasedAt: "2026-08-28 09:15 AM"
    },
    charges: [
      { description: "Ocean Freight (40HC Consolidated)", rate: "$58.00 / CBM", amount: 886.82, prepaid: true },
      { description: "Documentation & Electronic Customs Filing", rate: "Flat", amount: 160.00, prepaid: true },
      { description: "Port Security Surcharge", rate: "Flat", amount: 65.00, prepaid: true }
    ],
    totalFreightUsd: 1111.82
  },
  {
    id: "BL-VI-2026-0095",
    blNumber: "BL-VI-2026-0095",
    type: "Master Ocean Bill of Lading",
    status: "Draft",
    shipmentId: null,
    shipmentNumber: "UNASSIGNED",
    consolidationId: null,
    houseBillIds: [],
    createdDate: "2026-08-29",
    issueDate: "2026-08-29",
    shipper: {
      name: "SunState Textile Manufacturing Inc.",
      address: "5200 Sand Lake Rd, Orlando, FL 32819",
      taxId: "EIN-59-9948201",
      contact: "Elena Gomez (+1 407-555-9012)"
    },
    consignee: {
      name: "Port of Spain Retail Depot",
      address: "14 Frederick St, Port of Spain, Trinidad",
      taxId: "BIR-TT-109283",
      contact: "Kevin Ramcharan (+1 868-555-8910)"
    },
    notifyParty: {
      name: "Trinidad Shipping Services",
      address: "Wrightson Road, Port of Spain, Trinidad",
      contact: "Imports Desk (+1 868-555-3344)"
    },
    agentId: "AGT-004",
    agentName: "Trinidad Shipping Services",
    preCarriageBy: "SunState Express Trucking",
    placeOfReceipt: "Miami CFS",
    oceanVessel: "MV Tropical Navigator",
    voyageNumber: "V.2026-21E",
    carrier: "King Ocean Services",
    portOfLoading: "Port of Miami (USMIA)",
    portOfDischarge: "Port of Spain (TTPOS), Trinidad",
    placeOfDelivery: "Port of Spain CFS",
    containerNumber: "TBD-PENDING-LOADING",
    sealNumber: "TBD",
    containerType: "40' Standard GP",
    marksAndNumbers: "POS/TX/2026/0095",
    cargoDescription: "Finished Cotton Garments, Towels, Bed Linens in 30 Compressed Bales.",
    packageCount: 1,
    totalPieces: 30,
    packageType: "Bales",
    grossWeightLbs: 2100,
    grossWeightKg: 952.5,
    cbm: 11.89,
    cft: 420.0,
    freightPayableAt: "Port of Spain, Trinidad",
    freightTerms: "Freight Collect",
    numberOfOriginals: "3 (THREE)",
    holdDetails: {
      isOnHold: false,
      reason: null
    },
    charges: [
      { description: "Ocean Freight (LCL)", rate: "$62.00 / CBM", amount: 737.18, prepaid: false },
      { description: "Documentation Fee", rate: "Flat", amount: 125.00, prepaid: false }
    ],
    totalFreightUsd: 862.18
  }
];
